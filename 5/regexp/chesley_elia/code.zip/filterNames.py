import time
import re
#wordList = []
#wordListFile = "cracklib-small"
inputList = []
inputFile = "pg47010.txt"
nameList = []
namesListFile = "allNames.txt"
def filterDirectMatches():
    prefixes = ["Mr.", "Ms.", "Miss", "Mister", "Dr."]
    suffixes = ["Phd", "Jr", "Sr", "MD"]

#def filterFromWordList():
#    global inputList
#    for word in inputList:
#        if not(inWordList(word)):
#            print word

def filterFromNameList():
    global inputList
    for word in inputList:
        if inNameList(word):
            print word


    
def getInputList():
    global wordList, inputList
    f = open(inputFile, 'r')
    for word in re.split(" |-|,|\!|\?|\"|\'", f.read()):
        word = word.replace('\r', ' ')\
            .replace('\n', ' ')
        inputList.append(word.strip())
    f.close()


#def getWordList():
#    global wordListFile, wordList
#    f = open(wordListFile, 'r')
#    for line in f.readlines():
#        wordList.append(line.strip())
#    f.close()
#    wordList.sort()

def getNameList():
    startTime = time.time() * 1000
    global namesListFile, nameList
    f = open(namesListFile, 'r')
    for line in f.readlines():
        nameList.append(line.strip())
    f.close()
    print "Read all names (" + str(len(nameList)) + ") in " + str(time.time() * 1000 - startTime) + " ms"
    startTime = time.time() * 1000
    # Name list should be pre-sorted, but this is run just in case
    # If it is pre-sorted, the runtime of this sort will be negligible 
    nameList.sort()
    print "Sorted all names " + str(time.time() * 1000 - startTime) + " ms" 

#def inWordList(word):
#    global wordList
#    word = word.lower()
#    low = 0
#    high = len(wordList) - 1
#    while (low <= high):
#        middle = int(round((low + high) / 2))
#        if (word < wordList[middle]):
#            low = middle + 1;
#        elif (word > wordList[middle]):
#            high = middle - 1;
#        else:
#            return True
#    return False

def inNameList(word):
    global nameList
    low = 0
    high = len(nameList) - 1
    while (low <= high):
        middle = int(round((low + high) / 2))
        if (word > nameList[middle]):
            low = middle + 1;
        elif (word < nameList[middle]):
            high = middle - 1;
        else:
            return True
    return False

def filterCapitalizedAndBlanks():
    global inputList
    newList = []
    for word in inputList:
        if (len(word) > 0):
            if (not word[0].isupper()):
                inputList.remove(word) 
            else:
                newList.append(word)
        else:
            inputList.remove(word) 
    inputList = newList

def removeDuplicates(a_list, target):
    return [value for value in a_list if value != target]

if __name__ == "__main__":
    getInputList()
    getNameList()
    filterCapitalizedAndBlanks()
    filterFromNameList()


